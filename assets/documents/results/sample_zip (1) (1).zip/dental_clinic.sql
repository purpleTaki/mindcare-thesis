-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2022 at 06:57 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dental_clinic`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblclinic`
--

CREATE TABLE `tblclinic` (
  `ID` int(11) NOT NULL,
  `Cname` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Cnumber` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblclinic`
--

INSERT INTO `tblclinic` (`ID`, `Cname`, `Address`, `Cnumber`) VALUES
(1, 'Sample clinic', 'Mansilingan', '0978945612'),
(5, 'Dental clinic', 'Villamonte', '09237286327');

-- --------------------------------------------------------

--
-- Table structure for table `tbldoctor`
--

CREATE TABLE `tbldoctor` (
  `ID` int(11) NOT NULL,
  `Fname` varchar(25) NOT NULL,
  `Lname` varchar(25) NOT NULL,
  `Clinicname` varchar(50) NOT NULL,
  `ClinicAddress` varchar(50) NOT NULL,
  `Cnumber` varchar(12) NOT NULL,
  `DateCreated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbldoctor`
--

INSERT INTO `tbldoctor` (`ID`, `Fname`, `Lname`, `Clinicname`, `ClinicAddress`, `Cnumber`, `DateCreated`) VALUES
(1, 'Angelo', 'Morancil', 'Angelo clinic', 'Catleya street, brgy mansilingan, bacolod city', '09499679169', '2022-02-28 11:30:25'),
(2, 'John Christopher', 'Magnaye', 'John clinic', 'Sta fe, bacolod city', '09775787431', '2022-02-28 11:31:02'),
(3, 'Juan', 'De la cruz', 'Juan clinic', 'Galo lacson street, bacolod city', '12345678910', '2022-02-28 12:20:59'),
(5, 'Ella', 'Mae', 'Ella dental clinic', 'Villamonte', '09787945645', '2022-03-04 09:50:05'),
(7, 'Willie', 'Ong', 'Willie\'s dental clinic', 'Brgy. villamonte', '09123456789', '2022-03-21 09:42:27'),
(8, 'Juan ', 'Perez', 'Juan\'s dental clinic ', 'Brgy villamonte', '09123456789', '2022-03-21 09:49:28'),
(9, 'Louie', 'Ang', 'Ang\'s dental clinic', 'Brgy villamonte', '09123456789', '2022-03-21 10:03:44');

-- --------------------------------------------------------

--
-- Table structure for table `tbllaboratory`
--

CREATE TABLE `tbllaboratory` (
  `ID` int(11) NOT NULL,
  `Laboratory` varchar(100) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `Cost` double NOT NULL,
  `Groupnumber` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbllaboratory`
--

INSERT INTO `tbllaboratory` (`ID`, `Laboratory`, `Description`, `Cost`, `Groupnumber`) VALUES
(1, 'Digital Panoramic Dental Radiograph - Film', '', 20, 1),
(2, 'Digital Panoramic Dental Radiograph - Photopaper', '', 20, 1),
(3, 'Digital Cephalometric Dental Radiograph - Film', '', 20, 2),
(4, 'Digital Cephalometric Dental Radiograph - Photopaper', '', 30, 2),
(5, 'TMJ Radiograph (3 exposures) - Film', '', 50, 3),
(6, 'TMJ Radiograph (3 exposures) - Photopaper', '', 50, 3),
(7, 'CBCT U/L AREA', '', 40, 4),
(8, 'CBCT ARCH - UPPER', '', 50, 5),
(9, 'CBCT ARCH - LOWER', '', 50, 5),
(10, 'CBCT QUADRANT - ADULT', '', 50, 6),
(11, 'CBCT QUADRANT - CHILD', '', 60, 6);

-- --------------------------------------------------------

--
-- Table structure for table `tblpatient`
--

CREATE TABLE `tblpatient` (
  `ID` int(11) NOT NULL,
  `Fname` varchar(25) NOT NULL,
  `Lname` varchar(25) NOT NULL,
  `Age` int(2) NOT NULL,
  `Gender` varchar(25) NOT NULL,
  `Cnumber` varchar(12) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `DateCreated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblpatient`
--

INSERT INTO `tblpatient` (`ID`, `Fname`, `Lname`, `Age`, `Gender`, `Cnumber`, `Address`, `DateCreated`) VALUES
(2, 'Benjo', 'Mupas', 26, 'Male', '0933215456', 'Pulupandan', '2022-03-01 10:00:55'),
(3, 'Mary', 'Jane', 43, 'Female', '0932154565', 'Taculing', '2022-03-01 10:01:15'),
(5, 'Joseph', 'Reyes', 23, 'Male', '0986465413', 'Airport subd', '2022-03-09 11:24:56'),
(6, 'Nosmyol', 'Pay', 26, '', '0978645132', 'Kabankalan', '2022-03-09 15:54:42'),
(10, 'Sample', 'Sample', 1, 'Female', '0943135453', 'Sampel', '2022-03-12 13:25:20'),
(11, 'Angelo', 'Morancil', 23, 'Male', '0975463132', 'Brgy mansilingan', '2022-03-21 09:43:06'),
(12, 'Vincent', 'Dela cruz', 25, 'Male', '0945131254', 'Brgy taculing', '2022-03-21 09:50:09'),
(14, 'Ralph', 'Lopez', 23, 'Male', '0987654321', 'Brgy mansilingan', '2022-03-21 10:04:20'),
(15, 'Mark', 'Samson', 45, 'Male', '0978945612', 'Mansilingan', '2022-03-24 13:22:24');

-- --------------------------------------------------------

--
-- Table structure for table `tblrequest`
--

CREATE TABLE `tblrequest` (
  `ID` int(11) NOT NULL,
  `Doctor_id` int(11) NOT NULL,
  `Patient_id` int(11) NOT NULL,
  `Daterequest` datetime NOT NULL,
  `Totalbill` double NOT NULL,
  `Discount` double NOT NULL,
  `NetAmount` double NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Datepaid` datetime NOT NULL,
  `Datecreated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblrequest`
--

INSERT INTO `tblrequest` (`ID`, `Doctor_id`, `Patient_id`, `Daterequest`, `Totalbill`, `Discount`, `NetAmount`, `Status`, `Datepaid`, `Datecreated`) VALUES
(1, 5, 6, '2022-03-17 00:00:00', 20, 0, 0, 'UNPAID', '2022-03-11 11:00:03', '2022-03-11 10:00:20'),
(2, 3, 6, '2022-03-11 00:00:00', 100, 40, 60, 'PAID', '2022-03-18 16:57:05', '2022-03-11 10:02:18'),
(3, 5, 6, '2022-03-10 00:00:00', 30, 0, 0, 'UNPAID', '2022-03-16 16:05:02', '2022-03-11 14:23:45'),
(4, 3, 6, '2022-03-16 00:00:00', 600, 0, 600, 'PAID', '2022-03-23 11:02:55', '2022-03-11 16:21:13'),
(5, 3, 10, '2022-03-18 00:00:00', 30, 0, 30, 'PAID', '2022-03-18 15:12:13', '2022-03-12 13:25:31'),
(6, 1, 2, '2022-03-16 00:00:00', 170, 50, 120, 'PAID', '2022-03-21 09:31:05', '2022-03-17 14:55:17'),
(7, 7, 11, '2022-03-23 00:00:00', 100, 0, 100, 'PAID', '2022-03-23 11:02:30', '2022-03-21 09:43:47'),
(8, 8, 12, '2022-03-23 00:00:00', 70, 10, 60, 'PAID', '2022-03-21 09:52:26', '2022-03-21 09:50:37'),
(9, 9, 14, '2022-03-22 00:00:00', 150, 0, 150, 'PAID', '2022-03-21 10:06:23', '2022-03-21 10:04:42'),
(10, 1, 15, '2022-03-24 00:00:00', 90, 0, 90, 'PAID', '2022-03-24 13:29:16', '2022-03-24 13:22:50');

-- --------------------------------------------------------

--
-- Table structure for table `tblrequest_item`
--

CREATE TABLE `tblrequest_item` (
  `ID` int(11) NOT NULL,
  `Request_id` int(11) NOT NULL,
  `Laboratory_id` int(11) NOT NULL,
  `DateTaken` datetime NOT NULL,
  `ReleaseDate` datetime NOT NULL,
  `TakenBy` varchar(50) NOT NULL,
  `Cost` float NOT NULL,
  `Result` varchar(100) NOT NULL,
  `FileType` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblrequest_item`
--

INSERT INTO `tblrequest_item` (`ID`, `Request_id`, `Laboratory_id`, `DateTaken`, `ReleaseDate`, `TakenBy`, `Cost`, `Result`, `FileType`) VALUES
(1, 1, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 20, '', ''),
(2, 2, 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'angelo', 50, 'resbakuna-1-1536x1023.jpg', 'image/jpeg'),
(3, 2, 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'kim', 50, 'doc2.pdf', 'application/pdf'),
(4, 3, 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 30, '', ''),
(5, 4, 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 500, '', ''),
(6, 4, 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 100, 'Untitled.png', ''),
(7, 5, 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'mark', 50, '273763437_999997534264237_3987160986400148256_n.jpg', ''),
(8, 6, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'hihi', 20, 'doc2.pdf', 'application/pdf'),
(9, 6, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'asd', 100, '274702769_276671161247697_7277371144332617375_n (1).jpg', 'image/jpeg'),
(10, 6, 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'angelo', 50, '274233795_277215381219575_3381904913637818336_n.jpg', ''),
(11, 7, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'mark', 50, 'fcb80bd9-330c-404f-8c63-31e35945e709.jpg', 'image/jpeg'),
(12, 7, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'mark', 50, 'SAMPLE.pdf', 'application/pdf'),
(13, 8, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'anthony', 50, 'fcb80bd9-330c-404f-8c63-31e35945e709.jpg', 'image/jpeg'),
(14, 8, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'anthony', 20, 'SAMPLE.pdf', 'application/pdf'),
(15, 9, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'tony', 50, 'fcb80bd9-330c-404f-8c63-31e35945e709.jpg', 'image/jpeg'),
(16, 9, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'tony', 100, 'SAMPLE.pdf', 'application/pdf'),
(17, 10, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'edgardo', 20, 'permit.a61a2744.jpg', 'image/jpeg'),
(18, 10, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'edgardo', 50, 'fcb80bd9-330c-404f-8c63-31e35945e709.jpg', 'image/jpeg'),
(19, 10, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'edgardo', 20, 'fcb80bd9-330c-404f-8c63-31e35945e709.jpg', 'image/jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `tblsales`
--

CREATE TABLE `tblsales` (
  `ID` int(11) NOT NULL,
  `Date` datetime NOT NULL,
  `ORnum` varchar(100) NOT NULL,
  `Client` varchar(50) NOT NULL,
  `AmountPaid` double NOT NULL,
  `ReceiveBy` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblsales`
--

INSERT INTO `tblsales` (`ID`, `Date`, `ORnum`, `Client`, `AmountPaid`, `ReceiveBy`) VALUES
(1, '0000-00-00 00:00:00', '007', 'Angelo Morancil', 100, ''),
(2, '0000-00-00 00:00:00', '007', 'Angelo Morancil', 100, ''),
(3, '2022-03-23 00:00:00', '007', 'Angelo Morancil', 100, ''),
(4, '2022-03-16 00:00:00', '004', 'Nosmyol Pay', 600, ''),
(5, '2022-03-24 00:00:00', '0010', 'Mark Samson', 90, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblclinic`
--
ALTER TABLE `tblclinic`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbldoctor`
--
ALTER TABLE `tbldoctor`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbllaboratory`
--
ALTER TABLE `tbllaboratory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpatient`
--
ALTER TABLE `tblpatient`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblrequest`
--
ALTER TABLE `tblrequest`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblrequest_item`
--
ALTER TABLE `tblrequest_item`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblsales`
--
ALTER TABLE `tblsales`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblclinic`
--
ALTER TABLE `tblclinic`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbldoctor`
--
ALTER TABLE `tbldoctor`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbllaboratory`
--
ALTER TABLE `tbllaboratory`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tblpatient`
--
ALTER TABLE `tblpatient`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblrequest`
--
ALTER TABLE `tblrequest`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tblrequest_item`
--
ALTER TABLE `tblrequest_item`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tblsales`
--
ALTER TABLE `tblsales`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
